package clientlourd;

import java.sql.*;
import java.util.ArrayList;

/**
 * Classe qui gère la base de données
 * @author Kevin / Dan
 */
public class Connexion 
{
    Connection c;
	
    /**
     * Constucteur
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    public Connexion() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
	c = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/docks","root","");
    }
	
    /**
     * Connexion d'un utilisateur
     * @param _username Le nom de l'utilisateur
     * @param _password Son mot de passe
     * @return true si réussite, false sinon
     * @throws SQLException 
     */
    public boolean connect(String _username, String _password) throws SQLException
    {	
	Statement statement = c.createStatement();
	ResultSet resulset = statement.executeQuery("SELECT username, password FROM t_user WHERE username = '"+_username+"' AND password ='"+_password+"';");
	String resultUsername = new String();
	String resultPassword = new String();
	while(resulset.next())
        {
            resultUsername = resulset.getString("username");
            resultPassword = resulset.getString("password");
	}
	if(resultUsername.equals(_username) && resultPassword.equals(_password))
        {
            resulset.close();
            statement.close();
            return true;
	}
	else 
        {
            resulset.close();
            statement.close();
            return false;
	}
    }

    /**
     * Ajout d'un nouvel utilisateur
     * @param _nom Nom de l'utilisateur
     * @param _prenom Prénom de l'utilisateur
     * @param _username Username de l'utilisateur
     * @param _password Mot de passe de l'utilisateur
     * @param _email Mail de l'utilisateur
     * @return true si réussite, false sinon
     * @throws SQLException 
     */
    public boolean register(String _nom, String _prenom, String _username, String _password, String _email) throws SQLException
    {
        try (Statement statement = c.createStatement()) {
            int nbRows;
            
            if(checkUserExist(_username)) return false;
            
            nbRows = statement.executeUpdate("INSERT INTO t_user (nom, prenom, username, password, mail) VALUES ('"+_nom+"','"+_prenom+"','"+_username+"','"+_password+"','"+_email+"')");
            
            if(nbRows == 0) return false;
        }
		
	return true;
    }
    
    /**
     * Vérifie l'existance d'un utilisateur
     * @param _username Nom de l'utilisateur
     * @return true si l'utilisateur existe, false sinon
     * @throws SQLException 
     */
    public boolean checkUserExist(String _username) throws SQLException
    {
        Statement statement = c.createStatement();
        ResultSet resultset = statement.executeQuery("SELECT username FROM t_user WHERE username = '"+_username+"';");
                
        return resultset.next();
    }
    
    /**
     * Retourne l'id des projets d'un utilisateur
     * @param _username Le nom de l'utilisateur
     * @return une ArrayList d'integer contenant la liste des id de projets
     * @throws SQLException 
     */   
    public ArrayList<Integer> getProjects(String _username) throws SQLException
    {
        ArrayList<Integer> result = new ArrayList<>();
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT t_projet.id\n" +
            "FROM t_projet\n" +
            "INNER JOIN t_user_projet\n" +
            "   ON t_projet.id = t_user_projet.projet_id\n" +
            "INNER JOIN t_user\n" +
            "   ON t_user.id = t_user_projet.user_id\n" +
            "WHERE t_user.username = '"+_username+"';");
        while(resultset.next())
        {
            result.add(resultset.getInt("id"));
        }
            
        return result;
    }
    
    /**
     * Retourne le nom d'un projet grâce à son id
     * @param _id l'id du projet
     * @return un String contenant le nom du projet
     * @throws SQLException 
     */   
    public String getProjectName(int _id) throws SQLException
    {
        String result = new String();
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT nom\n" +
            "FROM t_projet\n" +
            "WHERE id = '"+_id+"';");
        while(resultset.next())
        {
            result = resultset.getString("nom");
        }
            
        return result;
    }
        
    /**
     * Retourne l'id des fichiers d'un projet
     * @param _idProjet L'id du projet
     * @return une ArrayList d'integer contenant la liste des id de fichiers
     * @throws SQLException 
     */
    public ArrayList<Integer> getFiles(int _idProjet) throws SQLException
    {
        ArrayList<Integer> result = new ArrayList<>();
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT t_fichier.id\n" +
            "FROM t_fichier\n" +
            "INNER JOIN t_fichier_projet\n" +
            "   ON t_fichier.id = t_fichier_projet.id_fichier\n" +
            "INNER JOIN t_projet\n" +
            "   ON t_fichier_projet.id_projet = t_projet.id\n" +
            "WHERE t_projet.id = '"+_idProjet+"';");
        while(resultset.next())
        {
            result.add(resultset.getInt("id"));
        }
            
        return result;
    }

    /**
     * Retourne le nom d'un fichier grâce à son id
     * @param _id L'id du fichier
     * @return un String contenant le nom du fichier
     * @throws SQLException 
     */
    public String getFileName(int _id) throws SQLException 
    {
        String result = new String();
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT nom\n" +
            "FROM t_fichier\n" +
            "WHERE id = '"+_id+"';");
        while(resultset.next())
        {
            result = resultset.getString("nom");
        }
            
        return result;
    }
        
    /**
     * Retourne le contenu d'un fichier grâce à son id
     * @param _id L'id du fichier
     * @return un String contenant le contenu du fichier
     * @throws SQLException 
     */
    public String getFileText(int _id) throws SQLException 
    {
        String result = new String();
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT texte\n" +
            "FROM t_fichier\n" +
            "WHERE id = '"+_id+"';");
        while(resultset.next())
        {
            result = resultset.getString("texte");
        }
            
        return result;
    }
    
    /**
     * Ajout d'un utilisateur à un projet
     * @param _username Nom de l'utilisateur à ajouter
     * @param _idProjet Id du projet
     * @return true si réussite, false sinon
     * @throws SQLException 
     */
    public boolean addUserToProject(String _username, int _idProjet) throws SQLException 
    {
        int idUser = 0;
        int result;
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT t_user.id\n" +
            "FROM t_user\n" +
            "WHERE username = '"+_username+"';");
            
        while(resultset.next())
        {
            idUser = resultset.getInt("id");
        }

        result = statement.executeUpdate("INSERT INTO t_user_projet (user_id, projet_id) VALUES ('"+idUser+"','"+_idProjet+"')");
        
        statement.close();
        
        return result != 0;
    }
    
    /**
     * Retourne les utilisateurs d'un projet
     * @param _idProjet L'id du projet
     * @return une ArrayList de String contenant l'username des utilisateurs 
     * @throws SQLException 
     */
    public ArrayList<String> getUsers(int _idProjet) throws SQLException 
    {
        ArrayList<String> result = new ArrayList<>();
        Statement statement = c.createStatement();
            
        ResultSet resultset = statement.executeQuery("SELECT username\n" +
                "FROM t_user\n" +
                "INNER JOIN t_user_projet\n" +
                "   ON t_user.id = t_user_projet.user_id\n" +
                "INNER JOIN projet\n" +
                "   ON t_user_projet.project_id = projet.id\n" +
                "WHERE projet.id = '"+_idProjet+"';");
        while(resultset.next())
        {
            result.add(resultset.getString("username"));
        }
            
        return result;
    }
    
    /**
     * Retire un utilisateur d'un projet
     * @param _username L'utilisateur à retirer
     * @param _idProjet L'id du projet
     * @throws SQLException 
     */
    public void removeUserToProject(String _username, int _idProjet) throws SQLException 
    {
        int idUser = 0;
        int result;
        Statement statement = c.createStatement();
        
        ResultSet resultset = statement.executeQuery("SELECT t_user.id\n" +
            "FROM t_user\n" +
            "WHERE username = '"+_username+"';");
            
        while(resultset.next())
        {
            idUser = resultset.getInt("id");
        }
		
	result = statement.executeUpdate("DELETE FROM t_user_projet WHERE projet_id = '"+_idProjet+"' AND user_id = '"+idUser+"'");
   
	statement.close();
    }

    /**
     * Ajout d'un fichier à un projet
     * @param _filename Nom du fichier
     * @param _idProjet Id du projet
     * @throws SQLException 
     */
    public void addFile(String _filename, int _idProjet) throws SQLException 
    {
        String sql = "INSERT INTO t_fichier (nom, texte) VALUES ('"+_filename+"','')";
 
        PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
 
        ps.execute();
 
        ResultSet resultset = ps.getGeneratedKeys();
        int generatedKey = 0;
        if (resultset.next()) 
        {
            generatedKey = resultset.getInt(1);
        }
        
        Statement statement = c.createStatement();
        
        int result = statement.executeUpdate("INSERT INTO t_fichier_projet (id_fichier, id_projet) VALUES ('"+generatedKey+"','"+_idProjet+"')");
            
        statement.close();
    }

    /**
     * Ajout d'un projet
     * @param _projet Nom du projet
     * @param _username Nom de l'utilisateur
     * @throws SQLException 
     */
    public void addProject(String _projet, String _username) throws SQLException 
    {
        int idProjet = 0;
        int idUser = 0;
        
        Statement statement = c.createStatement();
        
        ResultSet resultset = statement.executeQuery("SELECT t_user.id\n" +
            "FROM t_user\n" +
            "WHERE username = '"+_username+"';");
            
        while(resultset.next())
        {
            idUser = resultset.getInt("id");
        }
        
        String sql = "INSERT INTO t_projet (nom, id_admin) VALUES ('"+_projet+"','"+idUser+"')";
 
        PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
 
        ps.execute();
 
        resultset = ps.getGeneratedKeys();
        if (resultset.next()) 
        {
            idProjet = resultset.getInt(1);
        }
        
        int result = statement.executeUpdate("INSERT INTO t_user_projet (user_id, projet_id) VALUES ('"+idUser+"','"+idProjet+"')");
        
        statement.close();
    }

    /**
     * Sauvegarde un fichier
     * @param _idFile L'id du fichier
     * @param _file Le contenu du fichier
     * @throws SQLException 
     */
    public void save(int _idFile, String _file) throws SQLException 
    {
        Statement statement = c.createStatement();
        
        int result = statement.executeUpdate("UPDATE t_fichier SET texte = '"+_file+"' WHERE id = '"+_idFile+"';");
        
        statement.close();
    }
}